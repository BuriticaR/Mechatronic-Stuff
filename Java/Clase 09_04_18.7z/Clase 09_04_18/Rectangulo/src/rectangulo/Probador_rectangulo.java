
package rectangulo;

import javax.swing.JOptionPane;

public class Probador_rectangulo {
    public static void main(String args[]){
        Rectangulo a = new Rectangulo();
        double lado1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el lado 1: "));
        double lado2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el lado 2: "));
        a.setLado(lado1,lado2);
        JOptionPane.showMessageDialog(null,"El area  del rectangulo es: " + a.getArea());
        JOptionPane.showMessageDialog(null,"El perimetro  del rectangulo es: " + a.getPerimetro());
        JOptionPane.showMessageDialog(null,"La hipotenusa  del rectangulo es: " + a.getHiponetusa());
        
    }
    
    }
    
// LAS SOBRE CARGAS ES CUANDO VARIOS METODOS TIENEN ALGO PARECIDO Y SE LLAMEN DE LA MISMA MANERA
// SUS DIFERENCIAS PUEDEN SUS TIPOS DE DATOS ,

//LA HERENCIA SIRVE PARA NO ESCRIBIR LO QUE ESTA ESCRITO
// EL HIJO SIEMPRE HEREDA LOS ATRIBUTOS DEL PADRE
//

