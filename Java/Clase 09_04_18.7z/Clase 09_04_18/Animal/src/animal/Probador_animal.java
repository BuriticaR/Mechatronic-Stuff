/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
proxima clase interfaz grafica
clase que tenga que ver con los metodos
 */
package animal;
import javax.swing.JOptionPane;
public class Probador_animal {
public static void main(String args[]){

    int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad"));
    String nombre =(JOptionPane.showInputDialog("Ingrese el nombre: "));
    double tamano = Double.parseDouble(JOptionPane.showInputDialog("Ingrese tamaño: "));
    int ngm = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero de glandulas mamarias: "));
    
    Mamifero m = new Mamifero(ngm,nombre,edad,tamano);
    
    
    


}   
}
