/*
 Herencia
extends
*/
package animal;

/**
 *
 * @author estudiante
 */
public class Animal {

private String nombre;
private int edad;
private double tamano;

    public Animal(){}
    
    public Animal(String Animal,int edad, double tamano){
    this.nombre=nombre;
    this.edad=edad;
    this.tamano=tamano;
    }
    public void setNombre(String nombre){
    this.nombre=nombre;
    }
    public void setEdad(int edad){
    this.edad=edad;
    }
    public void setTamano(double nombre){
    this.tamano=tamano;
    }
    public String setNombre(){
    return nombre;
    }
    public int setEdad(){
    return edad;
    }
    public double setTamano(){
    return tamano;
    }
    
}
