/*
hallar area y perimetro e hipotenusa
 */
package clase_09_04_2018;

public class Clase_09_04_2018 {
    private double radio;

    public Clase_09_04_2018() { //constructor por defecto

    }

    public Clase_09_04_2018(double radio) { // constructor alternativo
        this.radio = radio;
    }

public void setRadio(double radio){   //todos los modificadores son void , metodo modificador
    this.radio=radio;
    }
public double getRadio(){  //metodos analizadores
    return radio;
}

public double getArea(){
return Math.PI*Math.pow(radio,2);// radio = base, exponente =2
}
public double getPerimetro(){
return 2*Math.PI*radio;

}
}
