/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase_09_04_2018;
import javax.swing.JOptionPane;
public class clase_04_04_2018 {
    public static void main (String args []){
        Clase_09_04_2018 a = new Clase_09_04_2018(); //clase_09_04_2018 = nombre es circulo
        double radio = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el radio: "));
        
        Clase_09_04_2018 b = new  Clase_09_04_2018(radio);
        a.setRadio(5); // se coloca el tamaño del radio
        JOptionPane.showMessageDialog(null,"El radio del circulo es: " + b.getRadio());
        JOptionPane.showMessageDialog(null,"El area del circulo es: " + a.getArea());
        JOptionPane.showMessageDialog(null,"El perimetro del circulo es: " + a.getPerimetro());  
    }

  
}
