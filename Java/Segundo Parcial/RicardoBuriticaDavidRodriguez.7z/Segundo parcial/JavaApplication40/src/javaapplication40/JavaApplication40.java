/*
Ejercicio numero 1 fila C
Ricardo Buritica 
David Rodriguez

 */
package javaapplication40;

import javax.swing.*;

public class JavaApplication40 {

    public static void main(String[] args) {
        int tam = Integer.parseInt(JOptionPane.showInputDialog("Diga el tamaño del vector: "));
        int c[] = new int[tam]; // tercera forma de crear un vector preguntale al usuario
        leerVector(c);
        mostrarVector(c);
        totaldinero(c);
        JOptionPane.showMessageDialog(null, "El promedio de las carreras  es: " + proVector(c));
        JOptionPane.showMessageDialog(null, "El dia que se hicieron mas carreras fue: " + mayorVector(c));
        JOptionPane.showMessageDialog(null, "El total dinero es: " + totaldinero(c));

    }

    static void leerVector(int x[]) {
        for (int i = 0; i < x.length; i++) {
            x[i] = Integer.parseInt(JOptionPane.showInputDialog("Ingrese elemento: "));

        }
    }

    static void mostrarVector(int x[]) {
        String m = "Numero de carreras diarias=[";
        for (int i = 0; i < x.length; i++) {
            m = m + x[i] + ",";
        }
        m = m + "J";
        JOptionPane.showMessageDialog(null, m);
    }
// promedio vector

    static double proVector(int a[]) {
        double sum = 0, pro = 0;
        for (int i = 0; i < a.length; i++) {
            sum = sum + a[i];

        }
        pro = sum / a.length;
        return pro;
    }
//carreras hizo

    static double mayorVector(int x[]) {

        int may = x[0], dia = 0;
        for (int i = 0; i < x.length; i++) {
            if (may < x[i]) {
                may = x[i];
                dia = i;
            }
        }
        return dia;
    }
//dinero total

    static double totaldinero(int p[]) {
        double sum_1 = 0, sum_2 = 0, sum_3 = 0;
        double sum_t = 0, sum_t2 = 0, sum_t3 = 0, sum_t4 = 0;
        for (int i = 0; i < p.length; i++) {
            if (p[i] <= 10) {
                sum_1 = sum_1 + p[i];
                sum_t = sum_1 * 2000;
            }
            if (p[i] >= 10 && p[i] <= 30) {
                sum_2 = sum_3 + p[i];
                sum_t2 = sum_1 * 4000;
            }
            if (p[i] > 30) {
                sum_3 = sum_3 + p[i];
                sum_t3 = sum_3 * 5000;
            }

        }
        sum_t4 = sum_t + sum_t2 + sum_t3;
        return sum_t4;
    }

}
